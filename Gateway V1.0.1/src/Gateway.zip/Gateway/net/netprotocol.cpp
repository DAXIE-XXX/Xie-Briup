#include "netprotocol.h"
#include "netdriver.h"
#include <QJsonObject>
#include <QJsonDocument>
#include "serialprotocol.h"
#include "appconfig.h"
#include "testpage.h"

NetProtocol * NetProtocol::obj = nullptr;
NetProtocol::NetProtocol(QObject *parent)
    : QObject{parent}
{
    connect(NetDriver::getObject(),
            &NetDriver::netRead,
            this,
            &NetProtocol::netReadSlot);
}

NetProtocol *NetProtocol::getObject()
{
    if(obj == nullptr)
        obj = new NetProtocol;
    return obj;
}

bool NetProtocol::login(QString id, QString key)
{
    QJsonObject jsonObj;
    jsonObj.insert("type", 8000);
    jsonObj.insert("index", id);
    jsonObj.insert("password", key);
    return NetDriver::getObject()
            ->netWrite(
                QJsonDocument(jsonObj).toJson());
}

bool NetProtocol::uploadSensorData(int co2, int ultravioletRays, double te1, double hu1, int lightIntensity, bool methane, bool fire, bool tsp, bool inf, int pm25, double te2, double hu2, bool opposingSensor, bool reflectionSensor)
{
    if(AppConfig::getIsLogin() && identification.isEmpty())
    {
        TestPage::getObject()->appendInfo(
                    QString("No login, try to login."));
        login(AppConfig::getDeviceID(),
              AppConfig::getCheckKey());
        return false;
    }
    QJsonObject jsonObj;
    jsonObj.insert("type", 1001);
    te1 = (double)(int)(te1 * 100) / 100.0;
    te2 = (double)(int)(te2 * 100) / 100.0;
    hu1 = (double)(int)(hu1 * 100) / 100.0;
    hu2 = (double)(int)(hu2 * 100) / 100.0;
    jsonObj.insert("te1", te1);
    jsonObj.insert("te2", te2);
    jsonObj.insert("hu1", hu1);
    jsonObj.insert("hu2", hu2);
    jsonObj.insert("co2", co2);
    jsonObj.insert("ultraviolet_rays", ultravioletRays);
    jsonObj.insert("light_intensity", lightIntensity);
    jsonObj.insert("methane", methane);
    jsonObj.insert("fire", fire);
    jsonObj.insert("tsp", tsp);
    jsonObj.insert("inf", inf);
    jsonObj.insert("pm25", pm25);
    jsonObj.insert("opposing", opposingSensor);
    jsonObj.insert("reflection", reflectionSensor);
    if(AppConfig::getIsLogin()){
        jsonObj.insert("identification", identification);
        jsonObj.insert("index", AppConfig::getDeviceID());
    }
    return NetDriver::getObject()
            ->netWrite(
                QJsonDocument(jsonObj).toJson());
}

void NetProtocol::netReadSlot(QByteArray data)
{
    int count = 0;
    for(int i = 0; i < data.length(); i++)
    {
        if(data.at(i) == '{')
        {
            //开头
            count++;
            //第一个括号，前面有无效数据
            if(i != 0 && count == 1){
                data = data.mid(i, data.length());
                i = 0;
                continue;
            }
        }
        else if(data.at(i) == '}')
        {
            //结束
            count--;
            if(count == 0)
            {
                QByteArray frame = data.mid(0, i+1);
                handleFrame(frame);
            }
        }
    }
}

void NetProtocol::handleFrame(const QByteArray &frame)
{
    QJsonObject obj =
        QJsonDocument::fromJson(frame).object();
    TestPage::getObject()->appendDebug(
            "Net read:" + frame);
    int type =
        obj.value("type").toInt();
    SerialProtocol *sp = SerialProtocol::getObject();
    if(type == 2001)
    {
        //高亮LED
        int id = obj.value("id").toInt();
        int brightness = obj.value("brightness").toInt();
        if(id == 1)
            sp->openLight1(brightness);
        else if(id == 2)
            sp->openLight2(brightness);
        else if(id == 3)
            sp->openLight3(brightness);
        else if(id == 4)
            sp->openLight4(brightness);
    }
    else if(type == 2002)
    {
        //炫彩LED
        int r,g,b;
        r = obj.value("r").toInt();
        g = obj.value("g").toInt();
        b = obj.value("b").toInt();
        sp->openRGBLED(r, g, b);
    }
    else if(type == 2003)
    {
        //普通设备
        int id = obj.value("id").toInt();
        bool sw = obj.value("sw").toBool();
        if(id == 1)
            sp->openAlarmBuzzer(sw);
        else if(id == 2)
            sp->openAlarmLight(sw);
        else if(id == 3)
            sp->openSteeringEngine(sw);
        else if(id == 4)
            sp->openStepperMotor(sw);
        else if(id == 5)
            sp->openFan(sw);
        else if(id == 6)
            sp->openRelay1(sw);
        else if(id == 7)
            sp->openRelay2(sw);
        else if(id == 8)
            sp->openLock(sw);
    }
    else if(type == 8001)
    {
        bool re = obj.value("re").toBool();
        if(re){
            identification = obj.value("identification").toString();
            TestPage::getObject()->appendInfo(QString("Login succeeded!"));
        }
        else
        {
            TestPage::getObject()->appendInfo(QString("Login failed!"));
        }
    }
    else if(type == 10000)
    {
        int errorId = obj.value("error_id").toInt();
        if(errorId == 1)
        {
            //未登录
            if(AppConfig::getIsLogin())
            {
                TestPage::getObject()->appendInfo(
                            QString("Login failed, try to login."));
                login(AppConfig::getDeviceID(),
                      AppConfig::getCheckKey());
            }else
            {
                TestPage::getObject()->appendInfo(
                            QString("Login is not allowed and cannot continue."));
            }
        }
    }
}












