INCLUDEPATH += $$PWD
QT += network

HEADERS += \
    $$PWD/netdriver.h \
    $$PWD/netprotocol.h

SOURCES += \
    $$PWD/netdriver.cpp \
    $$PWD/netprotocol.cpp
