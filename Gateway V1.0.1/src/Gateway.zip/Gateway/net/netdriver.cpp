#include "netdriver.h"
#include <QTcpSocket>
#include "testpage.h"
NetDriver *NetDriver::obj = nullptr;

NetDriver::NetDriver(QObject *parent)
    : QObject{parent}
    , client(new QTcpSocket)
{
    connect(client,
            &QTcpSocket::readyRead,
            this,
            &NetDriver::readyReadSlot);
    connect(client,
            &QTcpSocket::disconnected,
            this,
            &NetDriver::netDisconnected);
}

NetDriver::~NetDriver()
{
    if(client->state() == QTcpSocket::ConnectedState ||
        client->state() == QTcpSocket::ConnectingState)
    {
        client->disconnectFromHost();
        client->waitForDisconnected();
    }
}

NetDriver *NetDriver::getObject()
{
    if(obj==nullptr)
        obj=new NetDriver;
    return obj;
}

bool NetDriver::netConnectToServer(QString ip, quint16 port)
{
    if(client->state() == QTcpSocket::ConnectedState ||
        client->state() == QTcpSocket::ConnectingState)
    {
        client->disconnectFromHost();
        bool ok = client->waitForDisconnected(1000);
        if(!ok)
            return false;
    }
    client->connectToHost(
                ip, port);
    return client->waitForConnected(1000);
}

void NetDriver::netDisconnectFromServer()
{
    if(client->state() == QTcpSocket::ConnectedState ||
        client->state() == QTcpSocket::ConnectingState)
    {
        client->disconnectFromHost();
    }
}

bool NetDriver::netGetNetStatus()
{
    return client->state() ==
            QTcpSocket::ConnectedState ? true : false;
}

bool NetDriver::netWrite(const QByteArray &data)
{
    qint64 len = client->write(data);
    TestPage::getObject()
            ->appendDebug(
            "Net Send:" + data);
    if(len == data.length())
        return true;
    return false;
}

void NetDriver::readyReadSlot()
{
    QByteArray data;
    data = client->readAll();
    emit netRead(data);
}








