#ifndef NETDRIVER_H
#define NETDRIVER_H

#include <QObject>
class QTcpSocket;
/**
 * @brief 网络驱动类，提供基本的操作接口
 * @author Albert
 * @date 2022.8.19
 * @version V1.0
 */
class NetDriver : public QObject
{
    Q_OBJECT
protected:
    explicit NetDriver(QObject *parent = nullptr);

public:
    ~NetDriver();
    static NetDriver *getObject();
    /**
     * @brief 连接服务器
     * @param ip 服务器ip
     * @param port 服务器端口
     * @return 连接结果
     */
    bool netConnectToServer(QString ip, quint16 port);
    /**
     * @brief 断开与服务器的连接
     */
    void netDisconnectFromServer();
    /**
     * @brief 获取与服务器的连接状态
     *          此处只能获取TCP协议层面的连接状态
     * @return 连接状态
     */
    bool netGetNetStatus();
    /**
     * @brief 通过网络发送数据
     * @param data 要发送的数据
     * @return 发送的结果
     */
    bool netWrite(const QByteArray &data);

signals:
    /**
     * @brief 接收到的数据
     * @param data 数据
     */
    void netRead(QByteArray data);
    void netDisconnected();

protected slots:
    void readyReadSlot();

protected:
    static NetDriver *obj;
    QTcpSocket *client;
};

#endif // NETDRIVER_H
