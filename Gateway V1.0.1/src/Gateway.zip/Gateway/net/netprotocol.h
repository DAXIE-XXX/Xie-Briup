#ifndef NETPROTOCOL_H
#define NETPROTOCOL_H

#include <QObject>
/**
 * @brief 网络协议类，提供协议封装与解析
 * @author Albert
 * @date 2022.8.19 14:17
 * @version V1.0
 */
class NetProtocol : public QObject
{
    Q_OBJECT
protected:
    explicit NetProtocol(QObject *parent = nullptr);

public:
    static NetProtocol *getObject();
    /**
     * @brief login
     * @param id
     * @param key
     * @return
     */
    bool login(QString id, QString key);
    /**
     * @brief 上报传感器数据
     * @param 数据
     * @return bool 发送状态
     */
    bool uploadSensorData(
            int co2, int ultravioletRays,
            double te1, double hu1,
            int lightIntensity,
            bool methane, bool fire,
            bool tsp, bool inf,
            int pm25, double te2, double hu2,
            bool opposingSensor,
            bool reflectionSensor
            );

protected slots:
    void netReadSlot(QByteArray data);

protected:
    void handleFrame(const QByteArray &frame);
    static NetProtocol *obj;
    QString identification;
};

#endif // NETPROTOCOL_H
