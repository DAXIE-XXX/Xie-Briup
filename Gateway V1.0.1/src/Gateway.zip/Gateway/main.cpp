#include "testpage.h"
#include "serialdriver.h"
#include "serialprotocol.h"
#include <QApplication>
#include <QDebug>
#include "datacontrol.h"
#include "databuffer.h"
#include "netdriver.h"
#include "netprotocol.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    SerialDriver::getObject();
    SerialProtocol::getObject();
    DataControl::getObject();
    DataBuffer::getObject();
    NetDriver::getObject();
    NetProtocol::getObject();
    TestPage::getObject()->show();
    TestPage::getObject()->appendInfo("Gateway start.");
    return a.exec();
}
