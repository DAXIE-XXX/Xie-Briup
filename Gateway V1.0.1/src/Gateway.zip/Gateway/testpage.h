#ifndef TESTPAGE_H
#define TESTPAGE_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class TestPage; }
QT_END_NAMESPACE

class TestPage : public QWidget
{
    Q_OBJECT

protected:
    TestPage(QWidget *parent = nullptr);

public:
    static TestPage *getObject();
    ~TestPage();
    void appendInfo(QString info);
    void appendDebug(QString info);
    void updateSensor();

public slots:
    void on_btnConnect_clicked();

private slots:
    void netDisconnectedSlot();
    void on_btnSerialOpen_clicked();

    void on_btnLight1_clicked();

    void on_btnReqCo2_clicked();



    void on_btnSerialClose_clicked();

    void on_btnDisonnect_clicked();

    void on_btnLight2_clicked();

    void on_btnLight3_clicked();

    void on_btnLight4_clicked();

    void on_btnRGB_clicked();

    void on_btnReqInf_clicked();

    void on_btnReqUV_clicked();

    void on_btnReqTe1_clicked();

    void on_btnReqTe2_clicked();

    void on_btnReqLI_clicked();

    void on_btnReqHu1_clicked();

    void on_btnReqHu2_clicked();

    void on_btnReqFire_clicked();

    void on_btnReqRS_clicked();

    void on_btnReqMathane_clicked();

    void on_btnReqOS_clicked();

    void on_btnReqTSP_clicked();

    void on_btnReqPM25_clicked();

    void on_btnABOpen_clicked();

    void on_btnABClose_clicked();

    void on_btnALOpen_clicked();

    void on_btnALClose_clicked();

    void on_btnSEOpen_clicked();

    void on_btnSEClose_clicked();

    void on_btnSMOpen_clicked();

    void on_btnSMClose_clicked();

    void on_btnFanOpen_clicked();

    void on_btnFanClose_clicked();

    void on_btnRelay1Open_clicked();

    void on_btnRelay1Close_clicked();

    void on_btnRelay2Open_clicked();

    void on_btnRelay2Close_clicked();

    void on_btnLockOpen_clicked();

    void on_btnLockClose_clicked();

    void on_btnSendIntervalSave_clicked();

    void on_btnManualAndAuto_clicked();

    void on_btnSaveReqTime_clicked();

    void on_btnUpTimeSave_clicked();

    void on_btnUploadData_clicked();

    void on_btnIsDebug_clicked(bool checked);

    void on_btnSaveLoginInfo_clicked();

    void on_btnLogin_clicked(bool checked);

    void on_btnClear_clicked();

    void on_btnSaveInfo_clicked();

private:
    void loadConfig();
    static TestPage *obj;
    int appRunType = 0;//0-手动，1-自动
    bool isDebug = false;
    Ui::TestPage *ui;
};
#endif // TESTPAGE_H
