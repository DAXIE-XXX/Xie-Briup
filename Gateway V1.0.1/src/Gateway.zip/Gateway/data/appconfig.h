#ifndef APPCONFIG_H
#define APPCONFIG_H

#include <QObject>

class AppConfig : public QObject
{
    Q_OBJECT
protected:
    explicit AppConfig(QObject *parent = nullptr);

public:
    //串口：名称、波特率、发送间隔
    static QString getSerialPortName();
    static void setSerialPortName(QString name);
    static int getSerialBaudRate();
    static void setSerialBaudRate(int baudRate);
    static int getSerialSendInterval();
    static void setSerialSendInterval(int interval);
    //网络：ip、端口
    static QString getNetIp();
    static void setNetIp(QString ip);
    static int getNetPort();
    static void setNetPort(int port);
    static bool getIsLogin();
    static void setIsLogin(bool login);
    //设置：运行模式、上报间隔、请求间隔
    static int getRunType();
    static void setRunType(int type);
    static int getUploadTime();
    static void setUploadTime(int time);
    static int getRequestTime();
    static void setRequestTime(int time);
    static bool getIsDebug();
    static void setIsDebug(bool debug);
    static QString getDeviceID();
    static void setDeviceID(QString deviceID);
    static QString getCheckKey();
    static void setCheckKey(QString checkKey);

};

#endif // APPCONFIG_H
