#ifndef DATACONTROL_H
#define DATACONTROL_H

#include <QObject>
class QTimer;
/**
 * @brief 数据控制类
 * @author Albert
 * @date 2022.8.18
 * @version V1.0
 */
class DataControl : public QObject
{
    Q_OBJECT
protected:
    explicit DataControl(QObject *parent = nullptr);

public:
    /**
     * @brief 获取单例对象
     * @return 单例对象
     */
    static DataControl *getObject();
    /**
     * @brief 数据管理的方式
     */
    void autoControl();
    void manualControl();
    /**
     * @brief 重新加载定时器，需要当前是启动状态
     * @param s 秒
     */
    void reloadRequestTimer(int s);
    void reloadUploadTimer(int s);
    void uploadData();

protected slots:
    void requestTimerTimeoutSlot();
    void uploadTimerTimeoutSlot();

protected:
    static DataControl *obj;
    QTimer *requestTimer;
    QTimer *uploadTimer;
};

#endif // DATACONTROL_H
