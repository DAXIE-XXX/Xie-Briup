#include "databuffer.h"
DataBuffer *DataBuffer::obj = nullptr;
DataBuffer::DataBuffer(QObject *parent)
    : QObject{parent}
{

}

DataBuffer *DataBuffer::getObject()
{
    if(obj == nullptr)
        obj = new DataBuffer;
    return obj;
}
