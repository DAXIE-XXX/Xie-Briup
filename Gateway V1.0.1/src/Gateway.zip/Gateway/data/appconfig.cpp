#include "appconfig.h"
#include <QSettings>
#define FILENAME "config.ini"
#define SETGROUP "set"

#define SERIALNAME "serial_name"
#define SERIALBAUDRATE "serial_baudrate"
#define SERIALSENDINTERVAL "serial_send_interval"

#define NETIP "net_ip"
#define NETPORT "net_port"
#define ISLOGIN "login"

#define APPRUNTYPE "app_run_type"
#define UPLOADTIME "upload_time"
#define REQUESTTIME "request_time"
#define ISDEBUG "debug"
#define DEVICEID "device_id"
#define CHECKKEY "check_key"

AppConfig::AppConfig(QObject *parent)
    : QObject{parent}
{

}

QString AppConfig::getSerialPortName()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(SERIALNAME))
    {
        set.setValue(SERIALNAME, "No");
    }
    QString name = set.value(SERIALNAME)
            .toString();
    set.endGroup();
    return name;
}

void AppConfig::setSerialPortName(QString name)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(SERIALNAME, name);
    set.endGroup();
}

int AppConfig::getSerialBaudRate()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(SERIALBAUDRATE))
    {
        set.setValue(SERIALBAUDRATE, 57600);
    }
    int baudRate = set.value(SERIALBAUDRATE)
            .toInt();
    set.endGroup();
    return baudRate;
}

void AppConfig::setSerialBaudRate(int baudRate)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(SERIALBAUDRATE, baudRate);
    set.endGroup();
}

int AppConfig::getSerialSendInterval()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(SERIALSENDINTERVAL))
    {
        set.setValue(SERIALSENDINTERVAL, 700);
    }
    int interval = set.value(SERIALSENDINTERVAL)
            .toInt();
    set.endGroup();
    return interval;
}

void AppConfig::setSerialSendInterval(int interval)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(SERIALSENDINTERVAL, interval);
    set.endGroup();
}

QString AppConfig::getNetIp()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(NETIP))
    {
        set.setValue(NETIP, "127.0.0.1");
    }
    QString ip = set.value(NETIP)
            .toString();
    set.endGroup();
    return ip;
}

void AppConfig::setNetIp(QString ip)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(NETIP, ip);
    set.endGroup();
}

int AppConfig::getNetPort()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(NETPORT))
    {
        set.setValue(NETPORT, 20000);
    }
    int port = set.value(NETPORT)
            .toInt();
    set.endGroup();
    return port;
}

void AppConfig::setNetPort(int port)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(NETPORT, port);
    set.endGroup();
}

bool AppConfig::getIsLogin()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(ISLOGIN))
    {
        set.setValue(ISLOGIN, false);
    }
    bool debug = set.value(ISLOGIN)
            .toBool();
    set.endGroup();
    return debug;
}

void AppConfig::setIsLogin(bool login)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(ISLOGIN, login);
    set.endGroup();
}

int AppConfig::getRunType()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(APPRUNTYPE))
    {
        set.setValue(APPRUNTYPE, 0);
    }
    int type = set.value(APPRUNTYPE)
            .toInt();
    set.endGroup();
    return type;
}

void AppConfig::setRunType(int type)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(APPRUNTYPE, type);
    set.endGroup();
}

int AppConfig::getUploadTime()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(UPLOADTIME))
    {
        set.setValue(UPLOADTIME, 30);
    }
    int time = set.value(UPLOADTIME)
            .toInt();
    set.endGroup();
    return time;
}

void AppConfig::setUploadTime(int time)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(UPLOADTIME, time);
    set.endGroup();
}

int AppConfig::getRequestTime()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(REQUESTTIME))
    {
        set.setValue(REQUESTTIME, 30);
    }
    int time = set.value(REQUESTTIME)
            .toInt();
    set.endGroup();
    return time;
}

void AppConfig::setRequestTime(int time)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(REQUESTTIME, time);
    set.endGroup();
}

bool AppConfig::getIsDebug()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(ISDEBUG))
    {
        set.setValue(ISDEBUG, false);
    }
    bool debug = set.value(ISDEBUG)
            .toBool();
    set.endGroup();
    return debug;
}

void AppConfig::setIsDebug(bool debug)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(ISDEBUG, debug);
    set.endGroup();
}

QString AppConfig::getDeviceID()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(DEVICEID))
    {
        set.setValue(DEVICEID, "");
    }
    QString deviceID = set.value(DEVICEID)
            .toString();
    set.endGroup();
    return deviceID;
}

void AppConfig::setDeviceID(QString deviceID)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(DEVICEID, deviceID);
    set.endGroup();
}

QString AppConfig::getCheckKey()
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    QStringList keys = set.allKeys();
    if(!keys.contains(CHECKKEY))
    {
        set.setValue(CHECKKEY, "");
    }
    QString checkKey = set.value(CHECKKEY)
            .toString();
    set.endGroup();
    return checkKey;
}

void AppConfig::setCheckKey(QString checkKey)
{
    QSettings set(FILENAME, QSettings::IniFormat);
    set.beginGroup(SETGROUP);
    set.setValue(CHECKKEY, checkKey);
    set.endGroup();
}
