#include "datacontrol.h"
#include <QTimer>
#include "serialprotocol.h"
#include "netprotocol.h"
#include "databuffer.h"
#include "appconfig.h"
#include "testpage.h"

DataControl *DataControl::obj = nullptr;
DataControl::DataControl(QObject *parent)
    : QObject{parent}
    , requestTimer(new QTimer)
    , uploadTimer(new QTimer)
{
    connect(requestTimer, &QTimer::timeout,
            this, &DataControl::requestTimerTimeoutSlot);

    connect(uploadTimer, &QTimer::timeout,
            this, &DataControl::uploadTimerTimeoutSlot);
}

DataControl *DataControl::getObject()
{
    if(obj == nullptr)
        obj = new DataControl;
    return obj;
}

void DataControl::autoControl()
{
    requestTimer->start(
            AppConfig::getRequestTime()
                * 1000);
    uploadTimer->start(
            AppConfig::getUploadTime()
                * 1000);
}

void DataControl::manualControl()
{
    requestTimer->stop();
    uploadTimer->stop();
}

void DataControl::reloadRequestTimer(int s)
{
    if(requestTimer->isActive())
    {
        requestTimer->stop();
        requestTimer->start(s * 1000);
    }
}

void DataControl::reloadUploadTimer(int s)
{
    if(uploadTimer->isActive())
    {
        uploadTimer->stop();
        uploadTimer->start(s * 1000);
    }
}

void DataControl::uploadData()
{

    bool ok = NetProtocol::getObject()
        ->uploadSensorData(
            DataBuffer::getObject()->co2,
            DataBuffer::getObject()->ultravioletRays,
            DataBuffer::getObject()->te1,
            DataBuffer::getObject()->hu1,
            DataBuffer::getObject()->lightIntensity,
            DataBuffer::getObject()->methane,
            DataBuffer::getObject()->fire,
            DataBuffer::getObject()->tsp,
            DataBuffer::getObject()->inf,
            DataBuffer::getObject()->pm25,
            DataBuffer::getObject()->te2,
            DataBuffer::getObject()->hu2,
            DataBuffer::getObject()->opposingSensor,
            DataBuffer::getObject()->reflectionSensor);
    TestPage::getObject()->appendDebug(
                QString("Upload data:%1.")
                .arg(ok ? "ok" : "error"));
    if(!ok && AppConfig::getRunType() == 1)
    {
        TestPage::getObject()->on_btnConnect_clicked();
    }
}

void DataControl::requestTimerTimeoutSlot()
{
    SerialProtocol *sp = SerialProtocol::getObject();
    sp->requestCo2();
    sp->requestFire();
    sp->requestHu1();
    sp->requestHu2();
    sp->requestInf();
    sp->requestLightIntensity();
    sp->requestMethane();
    sp->requestOpposingSensor();
    sp->requestPm25();
    sp->requestReflectionSensor();
    sp->requestTe1();
    sp->requestTe2();
    sp->requestTsp();
    sp->requestUltravioletRays();
}

void DataControl::uploadTimerTimeoutSlot()
{
    uploadData();
}







