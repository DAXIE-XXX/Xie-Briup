#ifndef DATABUFFER_H
#define DATABUFFER_H

#include <QObject>
/**
 * @brief 缓冲、存储数据
 * @author Albert
 * @date 2022.8.18 14:00
 * @version V1.0
 */
class DataBuffer : public QObject
{
    Q_OBJECT
protected:
    explicit DataBuffer(QObject *parent = nullptr);

public:
    static DataBuffer *getObject();

    int co2 = 0;
    int ultravioletRays = 0;  //紫外线
    double te1 = 0;
    double hu1 = 0;
    int lightIntensity = 0;   //光照

    bool methane = false;          //甲烷
    bool fire = false;
    bool tsp = false;              //烟雾
    bool inf = false;

    int pm25 = 0;
    double te2 = 0;
    double hu2 = 0;

    bool opposingSensor = false;   //对射传感器
    bool reflectionSensor = false; //反射传感器

protected:
    static DataBuffer *obj;
};

#endif // DATABUFFER_H
