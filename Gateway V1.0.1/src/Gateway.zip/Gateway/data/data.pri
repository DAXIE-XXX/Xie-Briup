INCLUDEPATH += $$PWD

HEADERS += \
    $$PWD/appconfig.h \
    $$PWD/databuffer.h \
    $$PWD/datacontrol.h

SOURCES += \
    $$PWD/appconfig.cpp \
    $$PWD/databuffer.cpp \
    $$PWD/datacontrol.cpp
