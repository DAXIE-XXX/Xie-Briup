#include "serialprotocol.h"
#include "serialdriver.h"
#include "databuffer.h"
#include <QDebug>
#include <cmath>
#include "testpage.h"
using namespace std;
SerialProtocol *SerialProtocol::obj = nullptr;

SerialProtocol::SerialProtocol(QObject *parent)
    : QObject{parent}
{
    connect(SerialDriver::getObject(),
            &SerialDriver::serialRead,
            this,
            &SerialProtocol::serialReadSlot);
}

SerialProtocol *SerialProtocol::getObject()
{
    if(obj == nullptr)
      obj = new SerialProtocol;
    return obj;
}

bool SerialProtocol::openLight1(int brightness)
{
    if(brightness > 255)
        brightness = 255;
    if(brightness < 0)
        brightness = 0;
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x10;
    buf[7] = 0x11;
    buf[8] = brightness;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openLight2(int brightness)
{
    if(brightness > 255)
        brightness = 255;
    if(brightness < 0)
        brightness = 0;
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x10;
    buf[7] = 0x12;
    buf[8] = brightness;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openLight3(int brightness)
{
    if(brightness > 255)
        brightness = 255;
    if(brightness < 0)
        brightness = 0;
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x10;
    buf[7] = 0x13;
    buf[8] = brightness;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openLight4(int brightness)
{
    if(brightness > 255)
        brightness = 255;
    if(brightness < 0)
        brightness = 0;
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x10;
    buf[7] = 0x14;
    buf[8] = brightness;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openRGBLED(int r, int g, int b)
{
    if(r > 255)
        r = 255;
    if(r < 0)
        r = 0;
    if(g > 255)
        g = 255;
    if(g < 0)
        g = 0;
    if(b > 255)
        b = 255;
    if(b < 0)
        b = 0;
    int len = 12;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x10;
    buf[7] = 0x15;
    buf[8] = g;
    buf[9] = r;
    buf[10] = b;
    buf[11] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openAlarmBuzzer(bool sw)
{
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x50;
    buf[7] = 0x21;
    buf[8] = sw ? 0x01 : 0x02;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openAlarmLight(bool sw)
{
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x50;
    buf[7] = 0x22;
    buf[8] = sw ? 0x01 : 0x02;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openSteeringEngine(bool sw)
{
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x60;
    buf[7] = 0x25;
    buf[8] = sw ? 0x01 : 0x02;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openStepperMotor(bool sw)
{
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x70;
    buf[7] = 0x26;
    buf[8] = sw ? 0x01 : 0x02;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openFan(bool sw)
{
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x70;
    buf[7] = 0x27;
    buf[8] = sw ? 0x01 : 0x02;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openRelay1(bool sw)
{
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x70;
    buf[7] = 0x28;
    buf[8] = sw ? 0x01 : 0x02;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openRelay2(bool sw)
{
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x70;
    buf[7] = 0x29;
    buf[8] = sw ? 0x01 : 0x02;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::openLock(bool sw)
{
    int len = 10;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x80;
    buf[7] = 0x2A;
    buf[8] = sw ? 0x01 : 0x02;
    buf[9] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data);
}

bool SerialProtocol::requestCo2()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x20;
    buf[7] = 0x16;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestUltravioletRays()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x20;
    buf[7] = 0x17;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestTe1()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x20;
    buf[7] = 0x18;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestHu1()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x20;
    buf[7] = 0x19;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestLightIntensity()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x20;
    buf[7] = 0x2C;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestMethane()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x30;
    buf[7] = 0x1A;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestFire()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x30;
    buf[7] = 0x1B;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestTsp()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x30;
    buf[7] = 0x1C;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestInf()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x30;
    buf[7] = 0x1D;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestPm25()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x40;
    buf[7] = 0x1E;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestTe2()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x40;
    buf[7] = 0x1F;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestHu2()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x40;
    buf[7] = 0x20;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestOpposingSensor()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x50;
    buf[7] = 0x23;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

bool SerialProtocol::requestReflectionSensor()
{
    int len = 9;
    unsigned char buf[len];
    buf[0] = 0xFE;
    buf[1] = 0xFE;
    buf[2] = 0x00;
    buf[3] = 0xFF;
    buf[4] = 0xFF;
    buf[5] = len;
    buf[6] = 0x50;
    buf[7] = 0x24;
    buf[8] = 0xFF;
    QByteArray data;
    data.append((char *)buf, len);
    return SerialDriver::getObject()->serialWrite(data, 1);
}

void SerialProtocol::serialReadSlot(QByteArray data)
{
    temp.append(data);
    for(int i = 1; i < temp.length(); i++)
    {
        if((unsigned char)temp.at(i) == 0xEF &&
            (unsigned char)temp.at(i-1) == 0xEF)
        {
            //帧头
            if(i != 1)
            {
                temp = temp.mid(i-1, temp.length());
                i = 0;
                continue;
            }
            if(temp.length() < 9)
                return;
            int len = (unsigned char)temp.at(5);
            if(temp.length() < len)
                return;
            if((unsigned char)temp.at(len-1) == 0xFF)
            {
                //帧尾
                QByteArray frame = temp.mid(0, len);
                handleFrame(frame);
                temp = temp.mid(len, temp.length());
                continue;
            }
            else
            {
                temp = temp.mid(1, temp.length());
                i = 0;
                continue;
            }
        }
    }
}

void SerialProtocol::handleFrame(const QByteArray &frame)
{
    TestPage::getObject()->appendDebug(
            "Serial read:" + frame.toHex(' ').toUpper());
    int nodeId = (unsigned char)frame.at(6);
    int deviceId = (unsigned char)frame.at(7);
    TestPage *tp = TestPage::getObject();
    if(nodeId == 0x20 && deviceId == 0x16)
    {//co2
        int co2 = (unsigned char)frame.at(8) |
                ((unsigned char)frame.at(9) << 8);
        DataBuffer::getObject()->co2 = co2;
        tp->appendDebug(QString("Receive co2 %1")
                        .arg(co2));
    }
    if(nodeId == 0x20 && deviceId == 0x17)
    {
        int uv = (unsigned char)frame.at(8) |
                ((unsigned char)frame.at(9) << 8);
        DataBuffer::getObject()->ultravioletRays = uv;
        tp->appendDebug(QString("Receive uv %1")
                        .arg(uv));
    }
    if(nodeId == 0x20 && deviceId == 0x18)
    {//te1-实验箱
        /*int temp = ((unsigned char)frame.at(8) << 8) |
                (unsigned char)frame.at(9);
        double te = -46.85 + 175.72 *
                    (double)temp / pow(2, 16);
        qDebug() << te;
        DataBuffer::getObject()->te1 = te;*/
        //te-模拟设备
        double te = (unsigned char)frame.at(8) +
            ((double)((unsigned char)frame.at(9)) / 100.0);
        DataBuffer::getObject()->te1 = te;
        tp->appendDebug(QString("Receive te1 %1")
                        .arg(te));
    }
    if(nodeId == 0x20 && deviceId == 0x19)
    {
        double hu = (unsigned char)frame.at(8) +
            ((double)((unsigned char)frame.at(9)) / 100.0);
        DataBuffer::getObject()->hu1 = hu;
        tp->appendDebug(QString("Receive hu %1")
                        .arg(hu));
    }
    if(nodeId == 0x20 && deviceId == 0x2C)
    {
        int li = (unsigned char)frame.at(8) |
                ((unsigned char)frame.at(9) << 8);
        DataBuffer::getObject()->lightIntensity = li;
        tp->appendDebug(QString("Receive li %1")
                        .arg(li));
    }
    if(nodeId == 0x30 && deviceId == 0x1A)
    {
        bool sw = ((unsigned char)frame.at(8)) == 0x02 ? true : false;
        DataBuffer::getObject()->methane = sw;
        tp->appendDebug(QString("Receive methane %1")
                        .arg(sw));
    }
    if(nodeId == 0x30 && deviceId == 0x1B)
    {
        bool sw = ((unsigned char)frame.at(8)) == 0x02 ? true : false;
        DataBuffer::getObject()->fire = sw;
        tp->appendDebug(QString("Receive fire %1")
                        .arg(sw));
    }
    if(nodeId == 0x30 && deviceId == 0x1C)
    {
        bool sw = ((unsigned char)frame.at(8)) == 0x02 ? true : false;
        DataBuffer::getObject()->tsp = sw;
        tp->appendDebug(QString("Receive tsp %1")
                        .arg(sw));
    }
    if(nodeId == 0x30 && deviceId == 0x1D)
    {
        bool sw = ((unsigned char)frame.at(8)) == 0x02 ? true : false;
        DataBuffer::getObject()->inf = sw;
        tp->appendDebug(QString("Receive inf %1")
                        .arg(sw));
    }
    if(nodeId == 0x40 && deviceId == 0x1E)
    {
        int pm25 = (unsigned char)frame.at(8) |
                ((unsigned char)frame.at(9) << 8);
        DataBuffer::getObject()->pm25 = pm25;
        tp->appendDebug(QString("Receive pm2.5 %1")
                        .arg(pm25));
    }
    if(nodeId == 0x40 && deviceId == 0x1F)
    {
        double te = (unsigned char)frame.at(8) +
            ((double)((unsigned char)frame.at(9)) / 100.0);
        DataBuffer::getObject()->te2 = te;
        tp->appendDebug(QString("Receive te2 %1")
                        .arg(te));
    }
    if(nodeId == 0x40 && deviceId == 0x20)
    {
        double hu = (unsigned char)frame.at(8) +
            ((double)((unsigned char)frame.at(9)) / 100.0);
        DataBuffer::getObject()->hu2 = hu;
        tp->appendDebug(QString("Receive hu2 %1")
                        .arg(hu));
    }
    if(nodeId == 0x50 && deviceId == 0x23)
    {
        bool sw = ((unsigned char)frame.at(8)) == 0x02 ? true : false;
        DataBuffer::getObject()->opposingSensor = sw;
        tp->appendDebug(QString("Receive os %1")
                        .arg(sw));
    }
    if(nodeId == 0x50 && deviceId == 0x24)
    {
        bool sw = ((unsigned char)frame.at(8)) == 0x02 ? true : false;
        DataBuffer::getObject()->reflectionSensor = sw;
        tp->appendDebug(QString("Receive rs %1")
                        .arg(sw));
    }
    tp->updateSensor();
}











