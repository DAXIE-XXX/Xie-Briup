#ifndef SERIALPROTOCOL_H
#define SERIALPROTOCOL_H

#include <QObject>
/**
 * @brief 协议封装与解析类
 * @author Albert
 * @date 2022.8.16 10:00
 * @version V1.0
 */
class SerialProtocol : public QObject
{
    Q_OBJECT
protected:
    explicit SerialProtocol(QObject *parent = nullptr);

public:
    /**
     * @brief 获取单例对象
     * @return 对象
     */
    static SerialProtocol *getObject();
    /**
     * @brief openLight1~4 控制高亮led
     * @param brightness 亮度 0~255
     * @return 发送的结果，只代表数据是否成功发送
     */
    bool openLight1(int brightness);
    bool openLight2(int brightness);
    bool openLight3(int brightness);
    bool openLight4(int brightness);
    /**
     * @brief 控制炫彩LED
     * @param r 红色分量 0~255
     * @param g 绿色分量 0~255
     * @param b 蓝色分量 0~255
     * @return 发送的结果，只代表数据是否成功发送
     */
    bool openRGBLED(int r, int g, int b);
    /**
     * @brief 控制报警器或报警灯
     * @param sw 开关
     * @return 发送的结果，只代表数据是否成功发送
     */
    bool openAlarmBuzzer(bool sw);
    bool openAlarmLight(bool sw);
    /**
     * @brief 控制舵机
     * @param sw 开关
     * @return 发送的结果，只代表数据是否成功发送
     */
    bool openSteeringEngine(bool sw);
    /**
     * @brief 控制步进电机
     * @param sw 开关
     * @return 发送的结果，只代表数据是否成功发送
     */
    bool openStepperMotor(bool sw);
    /**
     * @brief 控制风扇
     * @param sw 开关
     * @return 发送的结果，只代表数据是否成功发送
     */
    bool openFan(bool sw);
    /**
     * @brief openRelay1~2 控制继电器
     * @param sw 开关
     * @return 发送的结果，只代表数据是否成功发送
     */
    bool openRelay1(bool sw);
    bool openRelay2(bool sw);
    /**
     * @brief 控制电磁锁
     * @param sw 开关
     * @return 发送的结果，只代表数据是否成功发送
     */
    bool openLock(bool sw);
    /**
     * @brief 请求二氧化碳数据
     * @return
     */
    bool requestCo2();
    bool requestUltravioletRays();  //紫外线
    bool requestTe1();
    bool requestHu1();
    bool requestLightIntensity();   //光照

    bool requestMethane();          //甲烷
    bool requestFire();
    bool requestTsp();              //烟雾
    bool requestInf();

    bool requestPm25();
    bool requestTe2();
    bool requestHu2();

    bool requestOpposingSensor();   //对射传感器
    bool requestReflectionSensor(); //反射传感器

protected slots:
    void serialReadSlot(QByteArray data);

protected:
    void handleFrame(const QByteArray &frame);

    static SerialProtocol *obj;
    QByteArray temp;
};

#endif // SERIALPROTOCOL_H
