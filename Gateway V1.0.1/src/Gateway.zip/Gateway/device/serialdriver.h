#ifndef SERIALDRIVER_H
#define SERIALDRIVER_H

#include <QObject>
class QSerialPort;
class QTimer;
/**
 * @brief 串口驱动类，提供基本的收发功能
 * @author Albert
 * @date 2022.8.15 15:00
 * @version V1.0
 */
class SerialDriver : public QObject
{
    Q_OBJECT
protected:
    explicit SerialDriver(QObject *parent = nullptr);

public:
    /**
     * @brief 获取单例对象
     * @return 对象
     */
    static SerialDriver *getObject();
    /**
     * @brief 获取系统中可用的串口
     * @return
     */
    static QStringList portList();

    /**
     * @brief 打开串口
     * @param name 串口名
     * @param baudrate 波特率
     * @return 打开结果
     */
    bool serialOpen(QString name, qint32 baudrate);
    /**
     * @brief 关闭串口
     */
    void serialClose();
    /**
     * @brief 发送数据
     * @param data 要发送的数据
     * @param type 0-优先模式，会追加到发送队列头部
     *             1-正常模式，会追加到发送队列尾部
     * @return 发送结果
     */
    bool serialWrite(const QByteArray &data,
                     int type = 0);
    /**
     * @brief 串口是否打开
     * @return 串口是否打开
     */
    bool serialIsOpen();
    /**
     * @brief 当前串口名称
     * @return 串口名称
     */
    QString serialGetName();
    /**
     * @brief 当前串口的波特率
     * @return 波特率
     */
    qint32 serialGetBaudRate();
    /**
     * @brief 重新加载定时器
     * @param time 新的时间
     */
    void reloadTimer(int time);

protected slots:
    void readyReadSlot();
    void sendTimerTimeoutSlot();

signals:
    /**
     * @brief 接收到数据
     * @param data 数据
     */
    void serialRead(QByteArray data);

protected:
    static SerialDriver *obj;
    QSerialPort *serial;
    QList<QByteArray> sendList;
    QTimer *sendTimer;
};







#endif // SERIALDRIVER_H
