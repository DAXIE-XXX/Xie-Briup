INCLUDEPATH += $$PWD
QT += serialport

HEADERS += \
    $$PWD/serialdriver.h \
    $$PWD/serialprotocol.h

SOURCES += \
    $$PWD/serialdriver.cpp \
    $$PWD/serialprotocol.cpp
