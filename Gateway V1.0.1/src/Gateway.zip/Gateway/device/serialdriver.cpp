#include "serialdriver.h"
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QDebug>
#include <QTimer>
#include "appconfig.h"
#include "testpage.h"

SerialDriver *SerialDriver::obj = nullptr;

SerialDriver::SerialDriver(QObject *parent)
    : QObject{parent}
    , serial(new QSerialPort)
    , sendTimer(new QTimer)
{
    //初始化串口
    serial->setDataBits(QSerialPort::Data8);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setParity(QSerialPort::NoParity);
    serial->setFlowControl(QSerialPort::NoFlowControl);

    //信号与槽绑定
    connect(serial, &QSerialPort::readyRead,
            this, &SerialDriver::readyReadSlot);
    connect(sendTimer, &QTimer::timeout,
            this, &SerialDriver::sendTimerTimeoutSlot);
    sendTimer->start(
            AppConfig::getSerialSendInterval()
                );
}

SerialDriver *SerialDriver::getObject()
{
    if(obj == nullptr)
        obj = new SerialDriver;
    return obj;
}

QStringList SerialDriver::portList()
{
    QStringList list;
    foreach (const QSerialPortInfo &info,
             QSerialPortInfo::availablePorts())
    {
        list.append(info.portName());
    }
    return list;
}

bool SerialDriver::serialOpen(QString name, qint32 baudrate)
{
    //判断原来的状态
    if(serial->isOpen())
        serial->close();
    //参数的配置
    serial->setPortName(name);
    serial->setBaudRate(baudrate);
    //打开
    return serial->open(QIODevice::ReadWrite);
}

void SerialDriver::serialClose()
{
    if(serial->isOpen())
        serial->close();
}

bool SerialDriver::serialWrite(const QByteArray &data,
                               int type)
{
    if(sendList.length() > 100)
        return false;
    if(type == 0)
    {
        //优先发送
        sendList.insert(0, data);
        return true;
    }
    else if(type == 1)
    {
        sendList.append(data);
        return true;
    }
    return false;
}

bool SerialDriver::serialIsOpen()
{
    return serial->isOpen();
}

QString SerialDriver::serialGetName()
{
    return serial->portName();
}

qint32 SerialDriver::serialGetBaudRate()
{
    return serial->baudRate();
}

void SerialDriver::reloadTimer(int time)
{
    sendTimer->stop();
    sendTimer->start(time);
}

void SerialDriver::readyReadSlot()
{
    QByteArray data = serial->readAll();
    emit serialRead(data);
}

void SerialDriver::sendTimerTimeoutSlot()
{
    if(sendList.isEmpty())
        return;
    qint64 len = serial->write(sendList.first());
    TestPage::getObject()->appendDebug(
          "Serial send:" + sendList.first().toHex(' ').toUpper());
    if(len != sendList.first().length())
        return;
    sendList.removeFirst();
}








