#include "testpage.h"
#include "ui_testpage.h"
#include "serialdriver.h"
#include "serialprotocol.h"
#include "netdriver.h"
#include "netprotocol.h"
#include <QColorDialog>
#include "appconfig.h"
#include "datacontrol.h"
#include <QDateTime>
#include <QFileDialog>
#include <QDebug>
#include "databuffer.h"

TestPage * TestPage::obj = nullptr;
TestPage::TestPage(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::TestPage)
{
    ui->setupUi(this);
    this->setWindowTitle("Gateway");
    ui->leCheckKey->setEchoMode(QLineEdit::Password);
    ui->cbSerialName->addItems(
            SerialDriver::portList());
    loadConfig();
    if(appRunType == 1)
    {
        on_btnSerialOpen_clicked();
        on_btnConnect_clicked();
        DataControl::getObject()
                ->autoControl();
    }
    connect(NetDriver::getObject(),
            &NetDriver::netDisconnected,
            this,
            &TestPage::netDisconnectedSlot);
}

TestPage *TestPage::getObject()
{
    if(obj == nullptr)
        obj = new TestPage;
    return obj;
}

TestPage::~TestPage()
{
    delete ui;
}

void TestPage::appendInfo(QString info)
{
    ui->textBrowser->append(QString("[%1]:%2")
                .arg(QDateTime::currentDateTime()
                     .toString("yyyy-MM-dd hh:mm:ss"))
                            .arg(info));
}

void TestPage::appendDebug(QString info)
{
    if(!isDebug)
        return;
    ui->textBrowser->append(QString("[%1](Debug):%2")
                .arg(QDateTime::currentDateTime()
                     .toString("yyyy-MM-dd hh:mm:ss"))
                            .arg(info));
    update();
}

void TestPage::updateSensor()
{
    ui->btnReqCo2->setText(QString("Request Co2(%1)")
                           .arg(DataBuffer::getObject()->co2));
    ui->btnReqFire->setText(QString("Request Fire(%1)")
                           .arg(DataBuffer::getObject()->fire));
    ui->btnReqHu1->setText(QString("Request Hu1(%1)")
                           .arg(DataBuffer::getObject()->hu1));
    ui->btnReqHu2->setText(QString("Request Hu2(%1)")
                           .arg(DataBuffer::getObject()->hu2));
    ui->btnReqTe1->setText(QString("Request Te1(%1)")
                           .arg(DataBuffer::getObject()->te1));
    ui->btnReqTe2->setText(QString("Request Te2(%1)")
                           .arg(DataBuffer::getObject()->te2));
    ui->btnReqInf->setText(QString("Request Inf(%1)")
                           .arg(DataBuffer::getObject()->inf));
    ui->btnReqLI->setText(QString("Request LI(%1)")
                           .arg(DataBuffer::getObject()->lightIntensity));
    ui->btnReqMathane->setText(QString("Request Methane(%1)")
                           .arg(DataBuffer::getObject()->methane));
    ui->btnReqOS->setText(QString("Request OS(%1)")
                           .arg(DataBuffer::getObject()->opposingSensor));
    ui->btnReqPM25->setText(QString("Request Pm2.5(%1)")
                           .arg(DataBuffer::getObject()->pm25));
    ui->btnReqRS->setText(QString("Request RS(%1)")
                           .arg(DataBuffer::getObject()->reflectionSensor));
    ui->btnReqTSP->setText(QString("Request TSP(%1)")
                           .arg(DataBuffer::getObject()->tsp));
    ui->btnReqUV->setText(QString("Request UV(%1)")
                           .arg(DataBuffer::getObject()->ultravioletRays));

}

void TestPage::netDisconnectedSlot()
{
    on_btnDisonnect_clicked();
}

void TestPage::on_btnSerialOpen_clicked()
{
    bool ok = SerialDriver::getObject()
        ->serialOpen(
            ui->cbSerialName->currentText(),
            ui->cbSerialBaudRate->currentText().toInt());
    if(ok)
    {
        AppConfig::setSerialPortName(
            ui->cbSerialName->currentText());
        AppConfig::setSerialBaudRate(
            ui->cbSerialBaudRate->currentText()
                    .toInt());
        ui->cbSerialBaudRate->setEnabled(false);
        ui->cbSerialName->setEnabled(false);
        ui->btnSerialOpen->setEnabled(false);
        ui->btnSerialClose->setEnabled(true);
    }
    appendInfo(QString("Open serialport name:%1,baudrate:%2,re:%3.")
               .arg(ui->cbSerialName->currentText())
               .arg(ui->cbSerialBaudRate->currentText())
               .arg(ok ? "ok" : "error"));
}

void TestPage::on_btnLight1_clicked()
{
    SerialProtocol::getObject()->openLight1(
                ui->hsLight1->value());
}

void TestPage::on_btnReqCo2_clicked()
{
    SerialProtocol::getObject()->requestCo2();
}


void TestPage::on_btnConnect_clicked()
{
    bool ok = NetDriver::getObject()
            ->netConnectToServer(
                ui->leIP->text(),
                ui->lePort->text().toInt()
                );
    if(ok)
    {
        AppConfig::setNetIp(
                ui->leIP->text());
        AppConfig::setNetPort(
                ui->lePort->text().toInt());
        ui->leIP->setEnabled(false);
        ui->lePort->setEnabled(false);
        ui->btnConnect->setEnabled(false);
        ui->btnDisonnect->setEnabled(true);
        if(ui->btnLogin->isChecked()){
            NetProtocol::getObject()->login(ui->leDeviceID->text(),
                                        ui->leCheckKey->text());
            appendInfo(QString("Login to server."));
        }
    }
    appendInfo(QString("Connect to host,ip:%1,port:%2,re:%3.")
               .arg(ui->leIP->text())
               .arg(ui->lePort->text())
               .arg(ok ? "ok" : "error"));
}

void TestPage::on_btnSerialClose_clicked()
{
    SerialDriver::getObject()->serialClose();
    ui->cbSerialBaudRate->setEnabled(true);
    ui->cbSerialName->setEnabled(true);
    ui->btnSerialOpen->setEnabled(true);
    ui->btnSerialClose->setEnabled(false);
    appendInfo(QString("Close serialport."));
}

void TestPage::on_btnDisonnect_clicked()
{
    NetDriver::getObject()->netDisconnectFromServer();
    ui->leIP->setEnabled(true);
    ui->lePort->setEnabled(true);
    ui->btnConnect->setEnabled(true);
    ui->btnDisonnect->setEnabled(false);
    appendInfo("Disconnected from host.");
}


void TestPage::on_btnLight2_clicked()
{
    SerialProtocol::getObject()->openLight2(
                ui->hsLight2->value());
}


void TestPage::on_btnLight3_clicked()
{
    SerialProtocol::getObject()->openLight3(
                ui->hsLight3->value());
}

void TestPage::on_btnLight4_clicked()
{
    SerialProtocol::getObject()->openLight4(
                ui->hsLight4->value());
}

void TestPage::on_btnRGB_clicked()
{
    QColor color = QColorDialog::getColor(
                Qt::white, this, "Select");
//    ui->lbRGB->setText(QString("RGB(%1,%2,%3)")
//                       .arg(color.red())
//                       .arg(color.green())
//                       .arg(color.blue()));
    ui->lbRGB_2->setStyleSheet(QString(
                "background-color:rgb(%1,%2,%3);")
               .arg(color.red())
               .arg(color.green())
               .arg(color.blue()));
    SerialProtocol::getObject()
            ->openRGBLED(color.red(), color.green()
                         ,color.blue());
}

void TestPage::on_btnReqInf_clicked()
{
    SerialProtocol::getObject()->requestInf();
}

void TestPage::on_btnReqUV_clicked()
{
    SerialProtocol::getObject()->requestUltravioletRays();
}

void TestPage::on_btnReqTe1_clicked()
{
    SerialProtocol::getObject()->requestTe1();
}

void TestPage::on_btnReqTe2_clicked()
{
    SerialProtocol::getObject()->requestTe2();
}

void TestPage::on_btnReqLI_clicked()
{
    SerialProtocol::getObject()->requestLightIntensity();
}

void TestPage::on_btnReqHu1_clicked()
{
    SerialProtocol::getObject()->requestHu1();
}

void TestPage::on_btnReqHu2_clicked()
{
    SerialProtocol::getObject()->requestHu2();
}

void TestPage::on_btnReqFire_clicked()
{
    SerialProtocol::getObject()->requestFire();
}

void TestPage::on_btnReqRS_clicked()
{
    SerialProtocol::getObject()->requestReflectionSensor();
}

void TestPage::on_btnReqMathane_clicked()
{
    SerialProtocol::getObject()->requestMethane();
}

void TestPage::on_btnReqOS_clicked()
{
    SerialProtocol::getObject()->requestOpposingSensor();
}

void TestPage::on_btnReqTSP_clicked()
{
    SerialProtocol::getObject()->requestTsp();
}

void TestPage::on_btnReqPM25_clicked()
{
    SerialProtocol::getObject()->requestPm25();
}

void TestPage::on_btnABOpen_clicked()
{
    SerialProtocol::getObject()->openAlarmBuzzer(true);
}

void TestPage::on_btnABClose_clicked()
{
    SerialProtocol::getObject()->openAlarmBuzzer(false);
}

void TestPage::on_btnALOpen_clicked()
{
    SerialProtocol::getObject()->openAlarmLight(true);
}

void TestPage::on_btnALClose_clicked()
{
    SerialProtocol::getObject()->openAlarmLight(false);
}

void TestPage::on_btnSEOpen_clicked()
{
    SerialProtocol::getObject()->openSteeringEngine(true);
}

void TestPage::on_btnSEClose_clicked()
{
    SerialProtocol::getObject()->openSteeringEngine(false);
}

void TestPage::on_btnSMOpen_clicked()
{
    SerialProtocol::getObject()->openStepperMotor(true);
}

void TestPage::on_btnSMClose_clicked()
{
    SerialProtocol::getObject()->openStepperMotor(false);
}

void TestPage::on_btnFanOpen_clicked()
{
    SerialProtocol::getObject()->openFan(true);
}

void TestPage::on_btnFanClose_clicked()
{
    SerialProtocol::getObject()->openFan(false);
}

void TestPage::on_btnRelay1Open_clicked()
{
    SerialProtocol::getObject()->openRelay1(true);
}

void TestPage::on_btnRelay1Close_clicked()
{
    SerialProtocol::getObject()->openRelay1(false);
}

void TestPage::on_btnRelay2Open_clicked()
{
    SerialProtocol::getObject()->openRelay2(true);
}

void TestPage::on_btnRelay2Close_clicked()
{
    SerialProtocol::getObject()->openRelay2(false);
}

void TestPage::on_btnLockOpen_clicked()
{
    SerialProtocol::getObject()->openLock(true);
}

void TestPage::on_btnLockClose_clicked()
{
    SerialProtocol::getObject()->openLock(false);
}

void TestPage::loadConfig()
{
    ui->cbSerialName->setCurrentText(
                AppConfig::getSerialPortName()
                );
    ui->cbSerialBaudRate->setCurrentText(
        QString("%1")
            .arg(
                AppConfig::getSerialBaudRate())
                );
    ui->leSendInterval->setText(
        QString("%1")
            .arg(
               AppConfig::getSerialSendInterval())
                );
    ui->leIP->setText(
            AppConfig::getNetIp());
    ui->lePort->setText(
            QString("%1")
                .arg(AppConfig::getNetPort()));
    appRunType = AppConfig::getRunType();
    if(appRunType == 0)
    {
        ui->btnManualAndAuto->setText("Manual");
    }
    else
    {
        ui->btnManualAndAuto->setText("Auto");
    }
    ui->leUpTime->setText(
        QString("%1")
            .arg(AppConfig::getUploadTime()));
    ui->leReqTime->setText(
        QString("%1")
            .arg(AppConfig::getRequestTime()));
    ui->btnIsDebug->setChecked(
        AppConfig::getIsDebug());
    isDebug = AppConfig::getIsDebug();
    ui->leDeviceID->setText(AppConfig::getDeviceID());
    ui->leCheckKey->setText(AppConfig::getCheckKey());
    ui->btnLogin->setChecked(AppConfig::getIsLogin());
}

void TestPage::on_btnSendIntervalSave_clicked()
{
    int interval = ui->leSendInterval->text()
            .toInt();
    if(interval < 500){
        ui->leSendInterval->setText("500");
        interval = 500;
    }
    else if(interval > 2000){
        ui->leSendInterval->setText("2000");
        interval = 2000;
    }
    AppConfig::setSerialSendInterval(interval);
    SerialDriver::getObject()
            ->reloadTimer(interval);
}

void TestPage::on_btnManualAndAuto_clicked()
{
    if(appRunType == 0)
    {
        //目前手动模式--》自动模式
        //定时上报数据功能打开
        //定时请求数据功能打开
        DataControl::getObject()
            ->autoControl();
        AppConfig::setRunType(1);
        ui->btnManualAndAuto->setText("Auto");
        appRunType = 1;
    }
    else
    {
        //目前自动模式--》手动模式
        DataControl::getObject()
            ->manualControl();
        AppConfig::setRunType(0);
        ui->btnManualAndAuto->setText("Manual");
        appRunType = 0;
    }
}

void TestPage::on_btnSaveReqTime_clicked()
{
    int time = ui->leReqTime->text().toInt();
    if(time < 10)
    {
        time = 10;
        ui->leReqTime->setText("10");
    }
    else if(time > 300)
    {
        time = 300;
        ui->leReqTime->setText("300");
    }
    AppConfig::setRequestTime(time);
    DataControl::getObject()
            ->reloadRequestTimer(time);
}

void TestPage::on_btnUpTimeSave_clicked()
{
    int time = ui->leUpTime->text().toInt();
    if(time < 10)
    {
        time = 10;
        ui->leUpTime->setText("10");
    }
    else if(time > 300)
    {
        time = 300;
        ui->leUpTime->setText("300");
    }
    AppConfig::setUploadTime(time);
    DataControl::getObject()
            ->reloadUploadTimer(time);
}

void TestPage::on_btnUploadData_clicked()
{
    DataControl::getObject()->uploadData();
}


void TestPage::on_btnIsDebug_clicked(bool checked)
{
    isDebug = checked;
    AppConfig::setIsDebug(checked);
}


void TestPage::on_btnSaveLoginInfo_clicked()
{
    AppConfig::setDeviceID(ui->leDeviceID->text());
    AppConfig::setCheckKey(ui->leCheckKey->text());
}


void TestPage::on_btnLogin_clicked(bool checked)
{
    AppConfig::setIsLogin(checked);
    if(checked){
        appendInfo(QString("Login method has changed, please login again."));
        on_btnDisonnect_clicked();
    }
}

void TestPage::on_btnClear_clicked()
{
    ui->textBrowser->clear();
}

void TestPage::on_btnSaveInfo_clicked()
{
    QString path = QFileDialog::getSaveFileName(
                this, "Select", QString("./info_%1.log").arg(QDateTime::currentDateTime()
                                                        .toString("yyyy_MM_dd_hhmmss")), "log file(*.log)");
    if(path.isEmpty())
        return;
    QString data = ui->textBrowser->toPlainText();
    QFile file(path);
    bool ok = file.open(QIODevice::WriteOnly);
    if(!ok)
        return;
    file.write(data.toLocal8Bit());;
    file.close();
}

