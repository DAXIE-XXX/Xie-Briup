#include "agreement.h"
#include "devices_usart01_debug.h"
#include "devices_usart02_zigbee.h"
app_agreement aa;
u8 down_buf[20]= {0};
u8 up_buf[20]= {0};
void downanalysis(u16 r_len,u8 *buf) {
//    int i=0;
//    if(buf[0]==0XFE&&buf[1]==0XFE&&\
//            buf[5]>=9&&\
//            buf[buf[5]-1]==0XFF) {
//        for(; i<buf[5]; i++) {
//            down_buf[i]=buf[i];
//        }
//        devices_usart02_zigbee_send_buf(down_buf[5], down_buf);
//    }
			devices_usart02_zigbee_send_buf(r_len, buf);
}
void upanalysis(u16 zr_len,u8 *buf) {
////    int i=0;
////    if(buf[0] ==0XEF &&buf[1]==0XEF &&\
////            buf[5]>=9 &&\
////            buf[buf[5]-1]==0XFF) {
////        for(; i<buf[5]; i++) {
////            up_buf[i] = buf[i];
////        }
////    }
//    devices_usart01_debug_send_buf(up_buf[5],up_buf);
	devices_usart01_debug_send_buf(zr_len,buf);
}

