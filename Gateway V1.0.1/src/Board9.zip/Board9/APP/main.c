#include "system_delay.h"
#include "system_option.h"
#include "config.h"
#include "devices_usart01_debug.h"
#include "devices_usart02_zigbee.h"
//����--->zigbee(9)--->zigbee(1-8)-->stm32
//stm32-->zigbee(1-8)->zigbee(9)->stm32->����1
#include "agreement.h"
#if App_Board_ID==9u
int main() {
    u16 r_len=0;
    u16 zr_len=0;
    u8 buf[200]= {0};
    u8 rebuf[200]= {0};
    system_delay_init(72);
    system_option_jtag_set(SWD_ENABLE);
    devices_usart01_debug_init(72,57600);
    devices_usart02_zigbee_init(36,57600);
    while(1) {
        r_len=devices_usart01_debug_read_buf(100,buf);
				zr_len=devices_usart02_zigbee_read_buf(100,rebuf);
        if (r_len == 0&&zr_len==0) {
            system_delay_us(10);
						continue;
        }
				if(r_len!=0){
        //����Э��
        if(buf[0]==0xFE&&buf[1]==0xFE) {
            //���������ĸ��豸
            downanalysis(r_len,buf);
        }
			}      
        //�ж��Ƿ���Ҫ�ϱ�����
        if(zr_len!=0) {
            if(rebuf[0]==0xEF&&rebuf[1]==0xEF) {
                upanalysis(zr_len,rebuf);
            }
        }
    }
}
#endif
