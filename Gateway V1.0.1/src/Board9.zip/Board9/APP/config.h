#ifndef __CONFIG_H
#define __CONFIG_H
#define App_Board_ID 9u
#define FUNC_DEBUG 0U
#endif