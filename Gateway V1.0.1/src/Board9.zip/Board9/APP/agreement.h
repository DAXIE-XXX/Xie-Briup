#ifndef __AGREEMENT_H
#define __AGREEMENT_H
#include "stm32f10x.h"

typedef struct {
    u8 addr; //�ڵ��
    u8 device;//�豸��
    u8 data_len	;//���ݳ���
    u8 data[32];//����
} app_agreement,*app_agreement_pt;

void app_dev_procotol(app_agreement_pt p);

void downanalysis(u16 r_len,u8 *buf);
void upanalysis(u16 zr_len,u8 *buf);
#endif